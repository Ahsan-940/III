# My AI

## Setup

### Backend
cd backend
cp .env.example .env
# fill in environment variables
npm install
npm run dev

### Frontend
cd frontend
npm install
npm run dev

Front end will run at http://localhost:5173 and proxies API calls to backend.

